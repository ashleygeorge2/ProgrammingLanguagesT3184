#include <iostream>
#include <jni.h>
#include <vector>
#include <fstream>
#include <string>
#include <memory>
#include <typeinfo>

using namespace std;

void GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
     JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
     JNIEnv *env;                      // Pointer to native interface
                                                              //================== prepare loading of Java VM ============================
     JavaVMInitArgs vm_args;                        // Initialization arguments
     JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
     options[0].optionString = (char*) "-Djava.class.path=";   // where to find java .class
     vm_args.version = JNI_VERSION_1_6;             // minimum Java version
     vm_args.nOptions = 1;                          // number of options
     vm_args.options = options;
     vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
                                                                          //=============== load and initialize Java VM and JNI interface =============
     jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
     delete options;    // we then no longer need the initialisation options.
     if (rc != JNI_OK) {
            // TO DO: error processing...
            cin.get();
            exit(EXIT_FAILURE);
     }
     //=============== Display JVM version =======================================
     cout << "JVM load succeeded: Version ";
     jint ver = env->GetVersion();
     cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

     jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
     if (cls2 == nullptr) {
            cerr << "ERROR: class not found !";
     }
     else {                                  // if class found, continue
            cout << "Class MyTest found" << endl;
            jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
            if (mid == nullptr)
                   cerr << "ERROR: method void createZooFile() not found !" << endl;
            else {
                   env->CallStaticVoidMethod(cls2, mid);                      // call method
                   cout << endl;
            }
     }


     jvm->DestroyJavaVM();
     cin.get();
}
string trim(string trimLine){ // trim spaces inside of strings
// removing spaces at the beginging of the string
	while(trimLine.size()&& isspace(trimLine.front()))trimLine.erase(trimLine.begin());
	//removing spacing at the end of the strings
	while(trimLine.size()&& isspace(trimLine.back()))trimLine.back();
	return trimLine;
//class for animals
struct Animal{
	string Name; // 15 characters
	int trackNum; // 6 characters
	Animal(string Name, int trackNum): Name(Name),trackNum(trackNum){}
	virtual~Animal(){}
};
struct Oviparous: public Animal{
	int eggNum;

	Oviparous(string Name, int trackNum, int eggnum): Oviparous(Name, trackNum, eggNum){}
};
struct Crocodile: public Oviparous{
	Crocodile(string Name, int trackNum, int eggNum): Oviparous(Name, trackNum, eggNum){}
};
struct Goose: public Oviparous{
	Goose(string Name, int trackNum, int eggNum): Oviparous(Name, trackNum, eggNum){}
};
struct Pelican: public Oviparous{
	Pelican(string Name, int trackNum, int eggNum): Oviparous(Name, trackNum, eggNum){}
};
struct Mammal: public Animal{
	int nurse;
	Mammal(string Name, int trackNum, int nurse): Animal(Name, trackNum), nurse(nurse){}
};
struct Bat: public Mammal{
	Bat(string Name, int trackNum, int nurse): Mammal(Name, trackNum, nurse){}
};
struct Whale: public Mammal{
	Whale(string Name, int trackNum, int nurse): Mammal(Name, trackNum, nurse){}
};
struct SeaLion: public Mammal{
	SeaLion(string Name, int trackNum, int nurse): Mammal(Name, trackNum, nurse){}

};

// vector for polymorph
vector<unique_ptr<Animal>>Zoo;
};

//functions for addding animals
void AddAnimal(){
	string trackNum;
	string Name;
	string Type;
	string subType;
	string eggNum;
	string nurse;
	char saveAnimal;

	cout << "Enter Tracking Number: " << endl;
	cin >> trackNum;
	cout << "Enter Animal Name: " << endl;
	cin.ignore();
	getline(cin, Name);
	cout << "Enter Animal Type: " << endl;
	cin >> Type;
	cout << " Enter Sub-Type: " << endl;
	cin >> subType;
	cout << "Enter Number of Eggs: " << endl;
	cin >> eggNum;
	cout >> "Enter Nursing: " << endl;
	cin >> nurse;

	cout << trackNum << " " << Name << " " << subType << " " << eggNum << " " << nurse << endl;
	cout << "Would you like to save animal information? " << " Press Y for YES, Press N for NO " << endl;
	cin >> saveAnimal;
	bool good = true;

	if(saveAnimal == 'Y'){

	for(int i = 0; i < trackNum.length(); i++){
     	if(!isdigit(trackNum[i])|| trackNum.length() > 6){
		cout << trackNum << " Must be a 6 digit number." << endl;
		good = false;
		break;


		}
	}

	for(int i = 0; i < eggNum.length(); i++){
	if(!isdigit(eggNum[i])){
		cout << eggNum << " Input was incorrect" << endl;
		good = false;
		break;
		}
	}

	for(int i = 0; i < nurse.length(); i++){
	if(!isdigit(nurse[i])){
		cout << nurse << " Input was incorrect" << endl;
		good = false;
		break;
		}
	}
	int trackNum1 = stoi(trackNum);
	int eggNum1 = stoi(eggNum);
	int nurse1 = stoi(nurse);

	if(Type != "Mammal" && Type != "Oviparous"){
		cout << Type << "Not Mammal or Oviparous" << endl;
		good = false;
	}
	if(Type == "Mammal"){
		if(subType != "Bat" && subType != "Whale" && subType != "SeaLion"){
			cout << subType << "Not a Bat, Whale, or SeaLion" << endl;
			good = false;
		}
	}else{
		if(subType != "Crocodile" && subType != "Goose" && subType != "Pelican"){
			cout << subType << "Not a Crocodile, Goose, or Pelican" << endl;
			good = false;

		}
	}
	if(eggNum1 > 0 && nurse1 > 0){
		cout << "We do not acquire this animal type..." << endl;
		good = false;
	}
	if(good){
		Name = Name.substr(0,15);

		if(Type == "Mammal"){
			if(subType == "Bat"){
				Zoo.push_back(unique_ptr<Animal>(new Bat(Name, trackNum1, nurse1)));
			}else if(subType == "Whale"){
				Zoo.push_back(unique_ptr<Animal>(new Whale(Name, trackNum1, nurse1)));
			}else{
				Zoo.push_back(unique_ptr<Animal>(new SeaLion(Name, trackNum1, nurse1)));
			}
		}else{
			if(subType == "Crocodile"){
				Zoo.push_back(unique_ptr<Animal>(new Crocodile(Name, trackNum1, eggNum1)));
			}else if(subType == "Goose"){
				Zoo.push_back(unique_ptr<Animal>(new Goose(Name, trackNum1, eggNum1)));
			}else{
				Zoo.push_back(unique_ptr<Animal>(new Pelican(Name, trackNum1, eggNum1)));
			}
		}
		cout << "Animal has been saved" << endl;
	}else{
		cout << "Error has occurred, Try Again." << endl;
	}
	return;
	}
}


void RemoveAnimal(){
	string remove;
	cout << "Enter Tracking Number to be Removed." << endl;
	cin >> remove;

	for(int i=0; i<remove.length(); i++){
		if(!isdigit(remove[i])|| remove.length() > 6){
			cout << remove << " Error has occurred, try again." << endl;
		return;
		}
	}
	int trackNum1 = stoi(remove);
	for(int i=0; i < Zoo.size(); i++){
		if(trackNum1 == static_cast<Animal*>(Zoo[i].get())->trackNum){
			Zoo.erase(Zoo.begin()+i);
			cout << "Data for Animal has been Deleted." << endl;
			return;
		}
	}
}



void LoadDataFromFile(){
	ifstream in("zoodata.txt");
	string lines;

while(getline(in, lines)){
	if(lines.size() > 0){
		int trackNum;
		string Name;
		string Type;
		string subType;
		int eggNum;
		int nurse;

		trackNum = stoi(lines.substr(0, 7));
		Name = trim(lines.substr(8, 15));
		Type = trim(lines.substr(25,15));
		subType = trim(lines.substr(4, 15));
		eggNum = stoi(lines.substr(59,1));
		nurse = stoi(lines.substr(61, 1));

		if(Type.find("Oviparous") != string::npos){
			if(subType.find("Crocodile") != string::npos){
				Zoo.push_back(unique_ptr<Animal>(new Crocodile(Name, trackNum, eggNum)));
			}
		if(subType.find("Goose") != string:: npos){
			Zoo.push_back(unique_ptr<Animal>(new Goose(Name, trackNum, eggNum)));
		}
		if(subType.find("Pelican") != string::npos){
			Zoo.push_back(unique_ptr<Animal>(new Pelican(Name, trackNum, eggNum)));

		}
	}

	if(Type.find("Mammal") != string::npos){
		if(subType.find("Bat") != string::npos){
			Zoo.push_back(unique_ptr<Animal>(new Bat(Name, trackNum, nurse)));
		}
		if(subType.find("Whale") != string::npos){
			Zoo.push_back(unique_ptr<Animal>(new Whale(Name,trackNum, nurse)));
		}
		if(subType.find("SeaLion") != string::npos){
			Zoo.push_back(unique_ptr<Animal>(new SeaLion(Name, trackNum, nurse)));
		}
		cout << "Data has been Loaded" << endl;
	}
}
}
}
//testing for animal type
string getType(int i){
	if(dynamic_cast<Mammal*>(Zoo[i].get()) != 0){
	return "Mammal";

}else{
	return "Oviparous";

}
}
string getsubType(int i){
	if(getType(i)== "Mammal"){
		if(dynamic_cast<Bat*>(Zoo[i].get()) != 0){
		return "Bat";
		}
	if(dynamic_cast<Whale*>(Zoo[i].get()) != 0){
		return "Whale";
	}
	if(dynamic_cast<SeaLion*>(Zoo[i].get()) != 0){
		return "SeaLion";
}else{
	if(dynamic_cast<Crocodile*>(Zoo[i].get()) != 0){
		return "Crocodile";
	}
	if(dynamic_cast<Goose*>(Zoo[i].get())!= 0){
		return "Goose";
	}
	if(dynamic_cast<Pelican*>(Zoo[i].get()) != 0){
		return "Pelican";
}
	return "Unable to Identify" << endl;
}

}
}

string padLeft(string str, int leng, string stringpadVal){
	for(int i = str.length(); i <= leng; i++);
	str = stringpadVal + str;
	return str;
}
string padRight(string str, int leng, string stringpadVal){
	for(int i = str.length(); i <= leng; i++)
		str = str + stringpadVal;
	return str;
}


// for layout padding
string dress(string trackNum, string Name, string Type, string subType, string eggNum, string nurse){
	string out = "";
	out += padLeft(track, 6, "0");

	out += "";
	out += padRight(Name, 15,"");

	out += "";
	out += padRight(type, 15, "");

	out += "";
	out += padRight(sub, 15, "");

	out += "";
	out += eggNum;

	out += "";
	out += nurse;

	return out;
}


void SaveDataToFile()
{
	ofstream out("zoodata.txt");
	for(unsigned int i = 0; i < Zoo.size(); i++){
		if(getType[i] == "Oviparous"){
			cout << dress(to_string(static_cast<Animal*>(Zoo[i].get())->trackNum), static_cast<Animal*>
			(Zoo[i].get())->Name, "Oviparous", getsubType(i), to_string(static_cast<Oviparous*>(Zoo[i].get())->eggNum), "0");
		}else if(getType(i) == "Mammal"){
			cout << dress(to_string(static_cast<Animal*>(Zoo[i].get())->trackNum), static_cast<Animal*>(Zoo[i].get())->Name,
					"Mammal", getsubType(i), "0", to_string(static_cast<Mammal*>(Zoo[i].get())->nurse));
		}
		if(i < Zoo.size()-1){
			cout << endl;
		}
	}
	cout << "Data was Saved" << endl;
}
// displaying menu options
void DisplayMenu(){
	cout << "Enter an Option: " << endl;
	cout << "1: Load Animal Data" << endl;
	cout << "2: Generate Data" << endl;
	cout << "3: Display Animal Data" << endl;
	cout << "4: Add Record" << endl;
	cout << "5: Delete Record" << endl;
	cout << "6: Save Animal Data" << endl;
	cout << "7: Finished" << endl;

}
// display animal data
void DisplayAnimal(){
	cout << Zoo.size() << " Animals Located" << endl;
	cout << dress(" Track# ", " Name ", " Type ", " Sub-Type ", " Eggs ", " Nurse ") << endl;

	for(unsigned int i = 0; i < Zoo.size(); i++){
		if(getType(i) == "Oviparous"){
			cout << dress(to_string(static_cast<Animal*>(Z00[i].get())->trackNum),
					static_cast<Animal*>(Zoo[i].get())->Name, "Oviparous", getsubType(i), to_string(static_cast<Oviparous*>(Zoo.[0].get())->eggNum),
					"0");
		}else if(getType(i) == "Mammal")
			cout << dress(to_string(static_cast<Animal*>(Zoo[i].get())->trackNum), static_cast<Animal*>(Zoo[i].get())->trackNum),
			static_cast<Animal*>(Zoo[i].get())->Name, "Mammal", getsubType(i), "0", to_string(static_cast<Mammal*>(Zoo[0].get())->nurse));
		}
	cout << endl;
	};



int main(){
	//calling data
	int option = 0;
	bool cont = false;

	do{
		while(cont){

		cont = true;

		DisplayMenu();
		cin >> option;

		switch(option){
		case 1:
			LoadDataFromFile();
			break;
		case 2:
			GenerateData();
			break;
		case 3:
			DisplayAnimalData();
			break;
		case 4:
			AddAnimal();
			break;
		case 5:
			RemoveAnimal();
			break;
		case 6:
			SavaDataToFile();
			break;
		case 7:

		default:

			cont = false;
			break;
		}

	GenerateData();

	return 1;
}



